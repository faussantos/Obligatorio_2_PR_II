#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void mostrarMenuPrincipal (int &opcion);

void mostrarMenuAltasBajas (int &opcion);
void mostrarMenuListados (int &opcion);
void mostrarMenuConsultas (int &opcion);

#endif // MENU_H_INCLUDED
