#ifndef BOOLEAN_H_INCLUDED
#define BOOLEAN_H_INCLUDED

typedef enum {FALSE, TRUE} boolean;

void cargaBool (boolean &b);

void printBool (boolean b);

#endif // BOOLEAN_H_INCLUDED
